import AccountType from './components/AccountType';
import Auth from './components/Auth';
import Balance from './components/Balance';
import Banking from './components/Banking';
import { Provider } from 'react-redux';
import { store } from './store/store';

function App() {
  return (
    <Provider store={store}>
      <Auth />
      <Balance />
      <Banking />
      <AccountType />
    </Provider>
  );
}

export default App;
