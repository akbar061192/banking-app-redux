import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { toggleAuth } from '../store/actions/authActions/authActionCreators';

const Auth = () => {
  const auth = useSelector(state => state.authReducer.isAuthenticated);
  const dispatch = useDispatch();

  const toggleUserAuth = () => {
    dispatch(toggleAuth());
  };

  return (
    <>
      <button className='btn btn-info' onClick={toggleUserAuth}>
        {auth ? 'Logout' : 'Login'}
      </button>
    </>
  );
};

export default Auth;
