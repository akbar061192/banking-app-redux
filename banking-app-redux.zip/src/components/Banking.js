import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { deposit, withdraw, getInterest, deleteAccount, changeAccountType } from '../store/actions/bankingActions/bankingActionCreators';

const Banking = () => {
  const [amount, setAmount] = useState(0);
  const dispatch = useDispatch();

  const depositAmount = () => {
    dispatch(deposit(amount));
  };

  const withdrawAmount = () => {
    dispatch(withdraw(amount));
  };

  const getAmountInterest = () => {
    dispatch(getInterest());
  };

  const deleteUserAccount = () => {
    dispatch(deleteAccount());
  };

  const changeUserAccountType = () => {
    dispatch(changeAccountType());
  };

  return (
    <>
      <div className='form-group'>
        <input type='number' value={amount} onChange={event => setAmount(+event.target.value)} className='form-control my-4 w-25' />
        <button className='btn btn-success mx-3' onClick={depositAmount}>
          Deposit
        </button>
        <button className='btn btn-primary mx-3' onClick={withdrawAmount}>
          Withdraw
        </button>
        <button className='btn btn-warning mx-3' onClick={getAmountInterest}>
          Get Interest
        </button>
        <button className='btn btn-danger mx-3' onClick={deleteUserAccount}>
          Delete Account
        </button>
        <button className='btn btn-light mx-3' onClick={changeUserAccountType}>
          Change Account Type
        </button>
      </div>
    </>
  );
};

export default Banking;
