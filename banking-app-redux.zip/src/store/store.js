import { createStore, combineReducers } from 'redux';
import { authReducer } from './actions/reducers/authReducer';
import { bankingReducer } from './actions/reducers/bankingReducer';

export const store = createStore(
  combineReducers({
    authReducer,
    bankingReducer,
  })
);
