import { bankingActions } from '../bankingActions/bankingActions';

const initialState = {
  balance: 0,
  isSavingAccount: true,
};

export const bankingReducer = (state = initialState, action) => {
  switch (action.type) {
    case bankingActions.DEPOSIT:
      return { ...state, balance: state.balance + action.payload.userAmount };
    case bankingActions.WITHDRAW:
      return { ...state, balance: state.balance - action.payload.userAmount };
    case bankingActions.GET_INTEREST:
      return { ...state, balance: state.balance * 1.03 };
    case bankingActions.DELETE_ACCOUNT:
      return { ...state, balance: 0 };
    case bankingActions.TOGGLE_ACCOUNT:
      return { ...state, isSavingAccount: !state.isSavingAccount };
    default:
      return state;
  }
};
