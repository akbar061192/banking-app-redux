import { bankingActions } from './bankingActions';

const deposit = amount => {
  return {
    type: bankingActions.DEPOSIT,
    payload: {
      userAmount: amount,
    },
  };
};

const withdraw = amount => {
  return {
    type: bankingActions.WITHDRAW,
    payload: {
      userAmount: amount,
    },
  };
};

const getInterest = () => {
  return {
    type: bankingActions.GET_INTEREST,
  };
};

const deleteAccount = () => {
  return {
    type: bankingActions.DELETE_ACCOUNT,
  };
};

const changeAccountType = () => {
  return {
    type: bankingActions.TOGGLE_ACCOUNT,
  };
};

export { deposit, withdraw, getInterest, deleteAccount, changeAccountType };
