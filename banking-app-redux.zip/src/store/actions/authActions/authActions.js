export const authActions = {
  TOGGLE_AUTH: 'TOGGLE_AUTH',
};
